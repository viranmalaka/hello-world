/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class Socket1 {
    public static void main(String[] args) {
        try {
            ServerSocket sk=new ServerSocket(5050);
            System.out.println("Server socket is starting");
            Socket s1=sk.accept();

            ObjectOutputStream oos=new ObjectOutputStream(s1.getOutputStream());
            ObjectInputStream ois=new ObjectInputStream(s1.getInputStream());

            
            String clientMsg=(String) ois.readObject();
            System.out.println("Client Message : "+clientMsg);
            oos.writeObject("Hi ");
            
        } catch (IOException ex) {
            Logger.getLogger(Socket1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Socket1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
