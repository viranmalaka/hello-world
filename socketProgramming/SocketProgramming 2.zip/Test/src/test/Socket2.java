/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student
 */
public class Socket2 {

    public static void main(String[] args) throws ClassNotFoundException {
        try {
            Socket s1 = new Socket("192.168.1.200", 5050);
            
            ObjectInputStream ois=new ObjectInputStream(s1.getInputStream());
            ObjectOutputStream oos=new ObjectOutputStream(s1.getOutputStream());

            oos.writeObject("Hello ");
            String clientMsg=(String) ois.readObject();
            System.out.println("Client Message : "+clientMsg);            
            
        } catch (IOException ex) {
            Logger.getLogger(Socket2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
